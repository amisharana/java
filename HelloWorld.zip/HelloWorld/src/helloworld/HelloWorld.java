package HelloWorld ;
import java.util.Scanner;
class University
{
	String uname;
	String uaddress;
	void  init()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print(" Enter Name of university = ");
		uname=sc.next();
		System.out.print(" Enter university Address= ");
		uaddress=sc.next();

		
	}
	void display()
	{
		System.out.println("University Name = "+uname);
		System.out.println("University Address = "+uaddress);
	}
}
class Student extends University
{
	String sname;
	
	String suid;
	void initial()
	{
		Scanner sc=new Scanner(System.in);
		System.out.print(" Enter the Name = ");
		sname=sc.next();
		System.out.print(" Enter UID = ");
		suid=sc.next();

	}
	void display()
	{
		super.display();
		System.out.println("Name = "+sname);

		System.out.println("UID = "+suid);
		
	}
}



   



public class HelloWorld{

     public static void main(String []args){
       Student obj=new Student();
 obj.init();
 obj.initial();
 obj.display();
     }
}
