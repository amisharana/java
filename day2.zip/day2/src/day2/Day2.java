/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2;

import java.util.Scanner;
import java.text.SimpleDateFormat;

public class Day2 {

    
    public static void main(String[] args) {
        
               int i, n, search, a[];
 
    Scanner sc = new Scanner(System.in);
      System.out.println("Enter number of elements");
        n = sc.nextInt();
      a = new int[n];
    
            
               System.out.println("Enter " + n + " integers");
 
                for (i = 0; i< n; i++)
                   a[i] = sc.nextInt();

        System.out.println("Enter an operator to be done: ");
         System.out.print("a. searching ");
         System.out.print("b.Sorting");
                 char num =sc.next().charAt(0);
                 
         
        
        
        switch(num)
        {
            case 'a':
            {
                
 
               System.out.println("Enter value to find");
               search = sc.nextInt();
   
                  for (i = 0; i < n; i++)
    {
      if (a[i] == search)     
      {
         System.out.println(search + " is present at location " + (i + 1) + ".");
          break;
      }
   }
  if (i == n)  
      System.out.println(search + " is not present in array.");
  

      break;
        }
            case 'b':
            {
        int temp,j;
       System.out.print("Sorting Array using Sort Technique..\n");  
       i=0;
       while(i<n)
       {  
           for(j=i+1; j<n; j++)  
           {  
               if(a[i] > a[j])  
               {  
                   temp = a[i];  
                   a[i] = a[j];  
                   a[j] = temp;  
               }  
           } 
           i++;
       }  
         
       System.out.print("Now the Array after Sorting is :\n");  
       for(i=0; i<n; i++)  
       {  
           System.out.print(a[i]+ "  ");  
       }
       
           
                  
   break; 
} 
            
                
            default:
                System.out.printf("Error! operator is not correct");
                return;
        }

            
    }
}
           
        
    
        
    
    
